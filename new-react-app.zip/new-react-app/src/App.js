import React from "react";
import Chatbot from './Chatbot';

const App = () =>{
    return (
        
		<div className="App"> <h1>
            Hello world! I am using React
        </h1> <Chatbot /> </div>
    )
}

export default App