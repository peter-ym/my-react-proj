import React, { useState } from 'react';
import axios from 'axios';
import './Chatbot.css';


const Chatbot = () => {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");

  const handleSend = async () => {
    if (input.trim()) {
      const newMessage = { sender: 'user', text: input };
      setMessages([...messages, newMessage]);
      setInput("");

      try {
        // const response = await axios.post('YOUR_API_ENDPOINT', { message: input });
        // const botMessage = { sender: 'bot', text: response.data.reply };
		const botMessage = { sender: 'bot', text: 'API is not yet integrated, so I am not able to answer your question!!'};
   		// Introducing a delay before showing the bot's message 
		setTimeout(() => { setMessages((prevMessages) => [...prevMessages, botMessage]); }, 1000); // 1-second delay
      } catch (error) {
        console.error("Error fetching API response:", error);
      }
    }
  };

  return (
    <div className="chatbot">
      <div className="messages">
        {messages.map((msg, index) => (
          <div key={index} className={`message ${msg.sender}`}>
            {msg.text}
          </div>
        ))}
      </div>
      <div className="input-container"> 
	  <input type="text" value={input} onChange={(e) => setInput(e.target.value)} /> 
	  <button onClick={handleSend}>Send</button> 
	  </div>
    </div>
  );
};

export default Chatbot;
